<?php
namespace ThemeMountain;
/**
 * the following has array in CMB2 format
 * https://github.com/WebDevStudios/CMB2/wiki/Field-Types#select
 */

$_local_plugin_dir_uri = TM_Admin_Options_OneClick::$local_plugin_dir_uri;
$_thememountain_ajax_nonce = wp_create_nonce('TM_Ajax_OneClick');
$_current_theme = wp_get_theme();
$_name_of_current_theme = 'ThemeMountain '.$_current_theme->get('Name');

TM_Admin_Options_OneClick::$option_metabox = array (
	array (
		'id' => 'tm_oneclick_concepts',
		'title' => esc_html__('Concepts','thememountain-oneclick'),
		'weight' => 0,
		'show_on' =>
		array (
			'key' => 'options-page',
			'value' =>
			array (
				'tm_oneclick_concepts',
				),
			),
		'show_names' => true,
		'fields' =>
		array (
			array (
				'name' => '',
				'id'   => 'import_site',
				'type' => 'title',
				'after' => '
				<!-- Title and Description Section -->
				<div class="section-block pt-40 pb-40 bkg-white">
					<div class="row full-width">
						<div class="column width-5 v-align-middle">
							<div>
								<h3 class="template-import-description mb-20">One Click Import for '.$_name_of_current_theme.'</h3>
								<p class="template-import-description lead mb-20">Welcome to Thememountain OneClick Concept. Choose your preferred concept and/or pages and click import.</p>
								<div class="box small rounded warning"><strong>Note:</strong> When importing ALL pages and post may be lost or overwritten. Pleae take a backup before importing a concept. Please use WordPress Reset or a clean install before importing if necessary.</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Title and Description Section End -->
				<!-- Filter Section -->
				<div class="section-block pt-0 pb-0 grid-filter-dropdown" data-target-grid="#template-grid">
					<div class="freeze pt-10 bkg-white" data-extra-space-top="0" data-extra-space-bottom="0">
						<div class="row full-width">
							<div class="column width-12">
								<div class="filter-menu-inner">
									<div class="row">
										<div class="column width-4 left">
											<span class="dropdown-label mb-0 mb-mobile-30">Filter Concepts: </span>
											<div class="form-select form-element rounded medium">
												<select id="concept-categories" name="concept-categories" data-label="All Categories">
													<option selected="selected" value="all">All Categories</option>
												</select>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Filter Section End -->

				<!-- Template Grid -->
				<div id="template-grid" class="section-block grid-container template-grid pt-30 pb-30" data-layout-mode="masonry" data-grid-ratio="1.5" data-animate-filter-duration="300">
					<div class="row full-width">
						<div class="column width-12">
							<div class="row grid content-grid-4">
								<div class="grid-item grid-sizer architecture">
									<div class="template with-background shadow">
										<div class="thumbnail">
											<img src="'.$_local_plugin_dir_uri.'/admin/assets/images/test_thumbnail.jpg" alt=""/>
										</div>
										<div class="template-details item-description">
											<div class="item-description-inner">
												<h4 class="project-title">Concept Title</h4>
												<span class="project-description">Template description goes here.</span>
											</div>
											<div class="template-actions pt-20">
												<button class="template-import-button rounded small inline-block mb-0 bkg-theme bkg-hover-theme color-white color-hover-white">Import Concept</button> <a href="#">View Demo</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>'
				)
		),
	),
);