(function ($) {
	"use strict";

	var FilterConcepts = function( element, options ){

		// Settings
		var settings = $.extend( {}, $.fn.filter.tmfOpts, options );

		// jQuery el
		element = $( element );

		// Filter Concept
		var filterConcepts = function( target ){
			if( target == 'all'|| target == ''){
				$( settings.filterGrid ).find( '.grid-item' ).each( function(){
					$( this ).show();
				});
			}else{
				$( settings.filterGrid ).find( '.grid-item' ).hide();
				$( settings.filterGrid ).find( '.' + target.toLowerCase() ).show();
			}
			_addGridSizer();
		};

		// Filter Select
		element.on( 'change', function( event ){
			var target = $(this).val();
			filterConcepts( target );
		});


	};

	// Plugin
	$.fn.filter = function( options ) {

		// Iterate through each DOM element and return it
		return this.each(function() {

			// Element
			var element = $( this );

			// Return early if this element already has a plugin instance
			if ( element.data( 'filter' ) ) return;

			// Pass options
			var filter = new FilterConcepts( this, options );

			// Store plugin object in this element's data
			element.data( 'filter', filter );

		});
	};

	// Default
	$.fn.filter.tmfOpts = {
		filterGrid: '.themeMountain_oneclick #template-grid'
	};

	/**
	 * Commonly used elements and variables
	 */
	var $gridPane;
	var $selectConceptCategories;
	var conceptCategories = {};

	/**
	 * Initial Screen
	 */
	$(document).ready(function() {
		$selectConceptCategories = $('select#concept-categories');
		$gridPane = $('div.tm-oneclick div.grid');
		get_concept_list();
	});


	/**
	 * On load, get a list then start populating the UI.
	 */
	function get_concept_list(){
		// init concept category once
		$selectConceptCategories.attr('disabled',true);
		conceptCategories = {};
		// show wait message
		$gridPane.html('<div class="row full-width"><div class="column"><h2>Please wait while loading.</h2></div></div>');
		$.ajax({
			'url': ajaxurl,
			'type': 'POST',
			'dataType': 'json',
			'data': {
				'action':'TM_Ajax_OneClick',
				'_tm_ajax_oneclick_nonce':tm_ajax_oneclick.tm_ajax_oneclick_nonce,
				'ajax_command': 'tmloadconcepts',
			}
		})
		.done(function( response ) {
			if(response.response === true && response.message) {
				$gridPane.html('');
				var _conceptList = response.message;
				var _extraClass = 'grid-sizer ';
				for(var _conceptID in _conceptList){
					$gridPane.append(_generateGridItem(_conceptID,_conceptList[_conceptID],_extraClass));
					_extraClass = '';
				}
				// populate category
				$selectConceptCategories.html('<option selected="selected" value="all">All Categories</option>');
				for(var _key in conceptCategories){
					$selectConceptCategories.append('<option value="'+_key+'">'+conceptCategories[_key]+'</option>');
				}
				// filter
				jQuery( '.themeMountain_oneclick #concept-categories' ).filter();
				// make select enabled
				$selectConceptCategories.attr('disabled',false);
			} else {
				var _errorMessage = 'There was an error in handling your request at the server. Please try again later.';
				if(response.response === false && response.message) {
					_errorMessage = response.message;
				}
				$gridPane.html('<div class="column width-12">'+_errorMessage+'</div>');
			}
		})
		.fail(function( response ) {
			$gridPane.html('There was an error in handling your request. Please try again later.');
		})
		.always(function( response ) {
		});
	}

	function _generateGridItem(conceptID,conceptData,extraClass){
		if(!extraClass) extraClass = '';
		var _gridItemHTML = '<div class="grid-item '+extraClass;
		// category
		if(conceptData.category) {
			// split to array
			var _concepts = conceptData.category.split(" ");
			// loop scan
			for(var _key in _concepts){
				// register each
				if(!(_concepts[_key] in conceptCategories)){
					conceptCategories[_concepts[_key]] = _capitalizeWords(_concepts[_key]);
				}
			}
			// add to the markup
			_gridItemHTML += conceptData.category;
		}
		_gridItemHTML += '"><div class="template with-background shadow"><div class="thumbnail">';
		// thumbnail image
		_gridItemHTML += '<img src="https://update.thememountain.com/oneclick/site_data/thumbnails/'+conceptID+'.jpg" class="lazyload">'
		_gridItemHTML += '</div><div class="template-details item-description"><div class="item-description-inner">';
		// title
		_gridItemHTML += '<h4 class="project-title">'+_capitalizeWords(conceptID)+'</h4>';
		// description
		if(conceptData.description) {
			_gridItemHTML += '<span class="project-description">'+conceptData.description+'</span>';
		}
		_gridItemHTML += '</div><div class="template-actions pt-20"><button class="template-import-button rounded small inline-block mb-0 bkg-theme bkg-hover-theme color-white color-hover-white" ';
		// id of the concept
		_gridItemHTML += 'data-concept-data-url="'+conceptData.file_basename+'"';
		_gridItemHTML += '>Import Concept</button> ';
		// demo url
		if(conceptData.demo_url) {
			_gridItemHTML += '<a href="'+conceptData.demo_url+'" target="_blank">View Demo</a>';
		} else {
			_gridItemHTML += '<a href="https://concepts.thememountain.com/'+conceptID+'/" target="_blank">View Demo</a>';
		}
		_gridItemHTML += '</div></div></div></div>';

		return _gridItemHTML;
	}

	function _capitalizeWords(textString){
		return textString.replace(/(-|^)([^-]?)/g, function(_, prep, letter) {
			return (prep && ' ') + letter.toUpperCase();
		});
	}

	/**
	 * Click event
	 */
	 $(document).on('click', 'button.template-import-button', function(event){
		event.preventDefault();

		// disable category
		$selectConceptCategories.attr('disabled',true);

		var _conceptID = $(event.target).attr('data-concept-data-url');

		$gridPane.html('<div class="row full-width"><div class="column"><h2>Wait while processing.</h2></div></div>');

		$.ajax({
			'url': ajaxurl,
			'type': 'POST',
			'dataType': 'json',
			'data': {
				'action':'TM_Ajax_OneClick',
				'_tm_ajax_oneclick_nonce':tm_ajax_oneclick.tm_ajax_oneclick_nonce,
				'ajax_command': 'importconceptsite',
				'concept_id': _conceptID
			}
		})
		.done(function( response ) {
			var _doRefresh = true;
			if(response.response === true) {
				$gridPane.html('<div class="row full-width"><div class="column"><h2>Site data imported</h2></div></div>');
			} else {
				var _errorMessage = '';
				if(response.response === false && response.message) {
					_errorMessage = response.message;
					_doRefresh = false;
				} else {
					_errorMessage = 'There was an error in handling your request at the server. Please try again later.';
				}
				$gridPane.html('<div class="row full-width"><div class="column"><h2>'+_errorMessage+'</h2></div></div>');
			}
			if(_doRefresh === true) setTimeout(function () { get_concept_list(); }, 5000);
		})
		.fail(function( response ) {
			$gridPane.html('<div class="row full-width"><div class="column"><h2>There was an error in handling your request. Please try again later.</h2></div></div>');
			setTimeout(function () { get_concept_list(); }, 5000);
		})
		.always(function( response ) {
		});
	});

	/**
	* Lazy Loading
	* .vc_templates-panel .vc_ui-panel-content
	*/
	// run
	function applyLazyLoad (){
		var $lazyInstance = $('#template-grid .grid-item .lazyload').lazyload();
	}

	// grid-sizer for masonry
	function _addGridSizer(){
		// remove .grid-sizer class from any underneath $vc_ui_template_content once
		$('#template-grid .grid-item').removeClass('grid-sizer');
		// add .grid-sizer to the first thumbnail within $vc_ui_template_content
		// for the isotope plugin
		$('#template-grid .grid-item').each(function(i,e){
			var $_gridItem = $(e);
			if($_gridItem.css('display') !== 'none') {
				// add the class
				$_gridItem.addClass('grid-sizer');
				// break out of jQuery each() method loop
				return false;
			}
		});
		applyMasonry();
	}
	$( window ).on( 'resize', function(){
		if( $('#template-grid').data('isotope') ) {
			$( '#template-grid' ).isotope( 'layout' );
		}
	});
})(window.jQuery);

/**
 * This function needs to be in the global scope because a modified version of lazyload.min.js requires it.
 */

function applyMasonry(){
	imagesLoaded( '#template-grid', function() {
		if( $('#template-grid').data('isotope') ) {
			jQuery( '#template-grid' ).isotope({
				filter: '*',
				itemSelector: '.grid-item',
				isResizeBound: false,
				transitionDuration: 700,
				layoutMode: 'fitRows',
				stamp: '.masonry-stamp',
				masonry: {
					// Specify grid item reference
					// Class added to the item selector.
					columnWidth: '.grid-sizer'
				}
			});
		} else {
			$( '#template-grid' ).isotope( 'layout' );
		}
	});
}