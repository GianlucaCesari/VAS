<?php
namespace ThemeMountain {
	/**
	 * Wordpress Import Manager class
	 * Written by Shu Miyao
	 * Some of the code derives from Duplicate Menu by Jonathan Christopher (http://mondaybynoon.com)
	 */
	class TM_Import_OneClick extends TM_Import {
		/**
		 * PROPERTIES
		 */

		/**
		 * Constructor
		 */
		public function __construct() {
		}

		/**
		 * Import site contents and options
		 *
		 * @see        ajax command, importsite
		 *
		 * @param      array 	$file_content		File content of site data
		 */
		public static function import_site_contents_and_options ($file_content) {
			// clone data
			self::$site_data = $file_content;
			// // import categories
			self::import_post_categories();
			// // import tm_folio_category custom taxonomy for tm_folio
			self::import_taxonomy_terms('tm_folio_category');
			// post types
			self::fetch_and_import_post_types_data();
			// navigation
			self::import_navigation_data();
			// customizer
			self::import_customizer_settings();
			// widgets
			self::import_widget_data();
			// Media Library attachments
			self::import_attachments();
			// Common settings
			// See Option Reference for details. https://codex.wordpress.org/Option_Reference
			self::import_common_site_settings_data();
		}


	}
}