<?php
namespace ThemeMountain {
	/**
	 * Wordpress Import Manager class
	 * Written by Shu Miyao
	 * Some of the code derives from Duplicate Menu by Jonathan Christopher (http://mondaybynoon.com)
	 */
	class TM_Import {
		/**
		 * PROPERTIES
		 */

		/**
		 * Data to output is accumulated in $site_data.
		 * Kept for reference only. Always refer Export class for the latest structure.
		 *
		 * @var        array
		 */
		protected static $site_data = array(
			/**
			 * Post data and its page options.
			 * Posts need to be published without password protection. Some fields are excluded from importation.
			 * Keys:
			 * 		post
			 * 		page
			 * 		tm_folio
			 * 		tm_footer
			 * 		tm_modal
			 * 		tm_preheader
			 * 		tm_error_page
			 * Each post stored as numbered array. Each array has associative array containing:
			 * 		ID
			 * 		post_date
			 * 		post_content (urlencoded)
			 * 		post_title (urlencoded)
			 * 		post_excerpt (urlencoded)
			 * 		comment_status
			 * 		post_name (urlencoded)
			 * 		post_parent
			 * 		guid
			 * 		menu_order
			 * 		post_type
			 * 		post_mime_type
			 * 		post_meta
			 * 			- _wp_page_template
			 * 			- _thumbnail_id
			 * 			- tm_* (Page Options)
			 */
			'posts' => array(
				'post' => array(),
				'page' => array(),
				'tm_folio' => array(),
				'tm_footer' => array(),
				'tm_modal' => array(),
				'tm_preheader' => array(),
				'tm_error_page' => array(),
				// contact form 7
				'wpcf7_contact_form' => array(),
			),
			/**
			 * Category / Taxonomies
			 *
			 * All the category data including meta such as "Custom Category Page".
			 */
			'taxonomies' => array(
				'category' => array(),
				'tm_folio_category' => array(),
			),
			/**
			 * Widget Settings and locations
			 *
			 * locations as associative array key
			 * 		associative array of widget id as key with its settings as its value.
			 */
			'widgets' => array(),
			'navigation' => array(),
			/**
			 * Customizer, ThemeMountain options. Option id is theme_mods_ followed by theme name.
			 */
			'customizer' => array(),
			/**
			 * Some of Default Wordpress Site Options which might appear in the Customizer
			 */
			'common_site_settings' => array(),
			/**
			 * Media Library
			 */
			'attachments' => array(),
		);

		/**
		 * Old to new translation table.
		 *
		 * @var        array
		 */
		private static $nav_menu_translation_table = array();
		// private static $category_translation_table = array();
		/**
		 * For both categories and taxonomies. Holds category / taxonomy term ids for translation
		 *
		 * @var        array
		 */
		private static $taxonomies_translation_table = array();

		/**
		 * Used for updating the featured image id.
		 *
		 * @var        array(post_id => _thumbnail_id)
		 */
		private static $post_thumbnail_id = array();

		/**
		 * Used for translating thumbnail_ids
		 *
		 * @var        array(old_id => new_id)
		 */
		private static $thumbnail_id_translation_table = array();

		/**
		 * Error log
		 */
		protected static $error_logs = array();

		/**
		 * METHODs
		 */

		/**
		 * Constructor
		 */
		public function __construct() {

		}

		/**
		 * All private functions for output_site_contents_and_options()
		 */

		/**
		 * Import post categories
		 *
		 * @uses       TM_Import::$site_data['category']
		 * @uses       TM_Import::$taxonomies_translation_table
		 */
		protected static function import_post_categories () {
			// set import data
			if(isset(self::$site_data['categories'])) {
				$_categories = self::$site_data['categories'];
			} else {
				return FALSE;
			}

			$_rescan_list_for_finding_parent = array();
			foreach ($_categories as $_value) {
				// remove category meta
				delete_option('tm_category_meta_'.$_value['term_id']);
				$_existing_category = get_category_by_slug($_value['slug']);
				if($_existing_category!==FALSE) {
					wp_delete_category($_existing_category->term_id);
				}
				// insert
				$_arg = array (
					'cat_name' => $_value['name'],
					'category_description' => $_value['description'],
					'category_nicename' => $_value['slug'],
					'taxonomy' => 'category'
				);
				// add
				$_assigned_id = wp_insert_category($_arg);
				// translate id
				self::$taxonomies_translation_table[$_value['term_id']] = $_assigned_id;
				// set for rescan. newly assigned id, old parent id
				array_push($_rescan_list_for_finding_parent,array($_assigned_id,$_value['parent']));

				// tm_category_meta
				if(is_array($_value['tm_category_meta'])) {
					add_option('tm_category_meta_'.$_assigned_id,$_value['tm_category_meta']);
				}
			}

			/**
			 * Loop once more just to set a new parent id.
			 *
			 * 1. Loop through $_rescan_list_for_finding_parent
			 * 2. If the old term id can be found in the translation table (self::$taxonomies_translation_table) ...
			 * 3. Update the parent id of the term
			 *   - $_value['term_id'] : old term id exported to the file
			 *   - $_category_id[0] : new term id
			 *   - $_category_id[1] : old parent id
			 */
			foreach ($_rescan_list_for_finding_parent as $_category_id ) {
				if(array_key_exists($_category_id[1], self::$taxonomies_translation_table)) {
					wp_update_term($_category_id[0],'category',array('parent'=>self::$taxonomies_translation_table[$_category_id[1]]));
				}
			}
		}

		/**
		 * Import folio categories
		 *
		 * @uses       TM_Import::$site_data['taxonomies']['tm_folio_category']
		 * @uses       TM_Import::$taxonomies_translation_table
		 */
		protected static function import_taxonomy_terms ($taxonomy) {
			// set import data
			if(isset(self::$site_data['taxonomies'][$taxonomy])) {
				$_folio_categories = self::$site_data['taxonomies'][$taxonomy];
			} else {
				return FALSE;
			}

			$_rescan_list_for_finding_parent = array();
			foreach ($_folio_categories as $_value) {
				// remove category meta
				delete_option('tm_category_meta_'.$_value['term_id']);
				$_existing_term = get_term_by( 'slug', $_value['slug'],'tm_folio_category');
				if($_existing_term != FALSE) {
					wp_delete_term($_existing_term->term_id,'tm_folio_category');
				}
				// insert
				$_arg = array (
					'description' => $_value['description'],
					'slug' => $_value['slug'],
				);
				// add
				$_assigned_id = wp_insert_term($_value['name'],'tm_folio_category',$_arg);
				$_assigned_id = $_assigned_id['term_id'];
				// translate id
				self::$taxonomies_translation_table[$_value['term_id']] = $_assigned_id;
				// set for rescan. newly assigned id, old parent id
				array_push($_rescan_list_for_finding_parent,array($_assigned_id,$_value['parent']));

				// tm_category_meta
				if(is_array($_value['tm_category_meta'])) {
					add_option('tm_category_meta_'.$_assigned_id,$_value['tm_category_meta']);
				}
			}

			/**
			 * Loop once more just to set a new parent id.
			 *
			 * 1. Loop through $_rescan_list_for_finding_parent
			 * 2. If the old term id can be found in the translation table (self::$taxonomies_translation_table) ...
			 * 3. Update the parent id of the term
			 *   - $_value['term_id'] : old term id exported to the file
			 *   - $_category_id[0] : new term id
			 *   - $_category_id[1] : old parent id
			 */
			foreach ($_rescan_list_for_finding_parent as $_category_id ) {
				if(array_key_exists($_category_id[1], self::$taxonomies_translation_table)) {
					wp_update_term($_category_id[0],'tm_folio_category',array('parent'=>self::$taxonomies_translation_table[$_category_id[1]]));
				}
			}
		}

		/**
		 * Fetch and set post type data for each post type.
		 *
		 * @uses       TM_Import::get_post_data()
		 */
		protected static function fetch_and_import_post_types_data() {
			$_post_types = array('post','page','tm_folio','tm_footer','tm_modal','wpcf7_contact_form','tm_error_page','tm_preheader');
			foreach($_post_types as $_post_type) {
				if(isset(self::$site_data['posts'][$_post_type])) {
					foreach (self::$site_data['posts'][$_post_type] as $_post_data) {
						// create post
						self::create_post_from_post_data($_post_data);
					}
				}
			}
		}

		/**
		 * Adds a post data to respective properties of post data.
		 * Just send a post data array. The rest will be taken care nicely.
		 *
		 * Data Structure
		 * Each post stored as numbered array. Each array has associative array containing:
		 * 		ID is translated into import_id, which is a suggested ID.
		 * 		post_date
		 * 		post_content (urlencoded)
		 * 		post_title (urlencoded)
		 * 		post_excerpt (urlencoded)
		 * 		comment_status
		 * 		post_name
		 * 		post_parent
		 * 		guid
		 * 		menu_order
		 * 		post_type
		 * 		post_mime_type
		 * 		post_meta
		 * 			- _wp_page_template
		 * 			- _thumbnail_id
		 * 			- tm_* (Page Options)
		 *
		 * @uses       TM_Import::$category_translation_table
		 * @uses       TM_Import::$taxonomies_translation_table
		 * @uses       TM_Import::$post_thumbnail_id
		 *
		 * @param      array  $post_data  The post data
		 *
		 * @return     array $_post_data_for_import Individual post date for import
		 */
		private static function create_post_from_post_data ($post_data) {
			// import post
			// translate data
			$_post_data_for_import = array(
				'import_id' => $post_data['ID'],
				'post_date' => $post_data['post_date'],
				'post_content' => html_entity_decode($post_data['post_content'],ENT_QUOTES,'UTF-8'),
				'post_title' => html_entity_decode($post_data['post_title'],ENT_QUOTES,'UTF-8'),
				'post_excerpt' => html_entity_decode($post_data['post_excerpt'],ENT_QUOTES,'UTF-8'),
				'comment_status' => $post_data['comment_status'],
				'post_name' => $post_data['post_name'],
				'post_parent' => $post_data['post_parent'],
				'guid' => $post_data['guid'],
				'menu_order' => $post_data['menu_order'],
				'post_type' => $post_data['post_type'],
				'post_mime_type' => $post_data['post_mime_type'],
				'post_status' => 'publish',
			);

			/**
			 * Find grid_item attributes of tm_grid, update all categories and taxonomies
			 */
			preg_match_all("/grid_items=\"(.*?)\"/", $_post_data_for_import['post_content'], $_grid_items);
			/**
			 * If there are any grid_items attributes found, analyze.
			 */
			if(isset($_grid_items[1]) && !empty($_grid_items[1])) {
				foreach ($_grid_items[1] as $_index_key => $_attribute_value) {
					$_attribute_value_array = explode('|',$_attribute_value);

					if(is_array($_attribute_value_array)){
						/** category Translates old term id of tm_grid Visual Composer query to the new ones. */
						foreach ($_attribute_value_array as $_key => $_value) {
							if(strpos($_value,'categories') !== FALSE || strpos($_value,'tax_query') !== FALSE){
								$_attribute_value_array[$_key] = self::_translate_term_id($_attribute_value_array[$_key]);
							}
						}
					}
					// put back together
					$_grid_items[1][$_index_key] = implode('|',$_attribute_value_array);
				}

				// loop, scan to replace with the translated settings
				foreach ($_grid_items[0] as $_index_key => $_attribute_value) {
					$_post_data_for_import['post_content'] = str_replace($_attribute_value, 'grid_items="'.$_grid_items[1][$_index_key].'"', $_post_data_for_import['post_content']);
				}
			}

			// delete old one
			wp_delete_post($post_data['ID'],TRUE);
			// create post
			$_assigned_post_id = wp_insert_post($_post_data_for_import);

			/**
			 * Categories / Taxonomies
			 */
			if($post_data['post_type'] === 'post' && array_key_exists('post_categories', $post_data)) {
				$_post_categories = $post_data['post_categories'];
				foreach ($_post_categories as $_key => $_value) {
					if(array_key_exists($_value, self::$taxonomies_translation_table)) {
						wp_set_post_categories(
							$_assigned_post_id,
							self::$taxonomies_translation_table[$_value],
							TRUE // supports multiple categories
						);
					}
				}
			} else if ($post_data['post_type'] === 'tm_folio' && array_key_exists('tm_folio_categories', $post_data)) {
				$_tm_folio_categories = $post_data['tm_folio_categories'];
				foreach ($_tm_folio_categories as $_key => $_value) {
					if(array_key_exists($_value, self::$taxonomies_translation_table)) {
						wp_set_post_terms(
							$_assigned_post_id,
							self::$taxonomies_translation_table[$_value],
							'tm_folio_category',
							TRUE // supports multiple categories
						);
					}
				}
			}

			// $_assigned_post_id should have post id if successful.
			if(!empty($_assigned_post_id)) {
				// set source post meta
				$_original_post_metadata = $post_data['post_meta'];
				if(array_key_exists('_thumbnail_id', $_original_post_metadata)) {
					self::$post_thumbnail_id[$_assigned_post_id] = $_original_post_metadata['_thumbnail_id'];
				}

				// scan through and add post meta one by one
				foreach ($_original_post_metadata as $_key => $_value) {
					update_post_meta($_assigned_post_id,$_key,$_value);
				}
			}
		}

		/**
		 * Support function to process id translation. Translates old term id of tm_grid Visual Composer query to the new ones.
		 * Format is key:value (string)
		 *
		 * @uses       TM_Import:create_post_from_post_data()
		 *
		 * @return     Attribute value array
		 */
		private static function _translate_term_id($attribute_data) {
			$attribute_data = explode(':',$attribute_data);
			$_attribute_name = $attribute_data[0];
			$_attribute_value = $attribute_data[1];
			$_taxonomy_setting_array = explode(',',$_attribute_value);
			foreach ($_taxonomy_setting_array as $_taxonomy_setting_array_key => $_taxonomy_setting_array_value) {
					// translate
				if(array_key_exists($_taxonomy_setting_array_value,self::$taxonomies_translation_table)) {
					$_taxonomy_setting_array[$_taxonomy_setting_array_key] = self::$taxonomies_translation_table[$_taxonomy_setting_array_value];
				}
			}
			$attribute_data = $_attribute_name.':'.implode(',',$_taxonomy_setting_array);
			return $attribute_data;
		}

		/**
		 * Import Customizer settings
		 *
		 * @uses      TM_Import::$site_data['customizer'];
		 */
		protected static function import_customizer_settings (){
			// set import data
			if(isset(self::$site_data['customizer'])) {
				$_customizer_settings_for_import = self::$site_data['customizer'];
			} else {
				return FALSE;
			}

			/**
			 * Reset all except for sidebars_widgets, custom_css_post_id, nav_menu_locations
			 */
			$_current_template_id = get_option('stylesheet');
			// constant
			$_ignore_list = array('0','sidebars_widgets','custom_css_post_id', 'nav_menu_locations');
			// source data
			$_theme_mods = get_option('theme_mods_'.$_current_template_id);

			// scan through to set settings to default by eliminating remaining settings.
			foreach ($_theme_mods as $_key => $_value) {
				if(!in_array($_key,$_ignore_list)) {
					unset($_theme_mods[$_key]);
				}
			}

			// scan through to import options
			foreach ($_customizer_settings_for_import as $_key => $_value) {
				if(!in_array($_key,$_ignore_list)) {
					$_theme_mods[$_key] = $_value;
				}
			}

			// set $_theme_mods once again to finish the resetting
			update_option('theme_mods_'.$_current_template_id,$_theme_mods);
		}

		/**
		 * Imports widgets.
		 *
		 * @uses       TM_Import::set_sidebar_widget_options()
		 */
		protected static function import_widget_data () {
			// set import data
			if(isset(self::$site_data['widgets'])) {
				$_sidebars_widgets_data_for_import = self::$site_data['widgets'];
			} else {
				return FALSE;
			}

			/**
			 * Scan and set widget to respective locations
			 */
			$_sidebars_widgets = get_option('sidebars_widgets');
			foreach ($_sidebars_widgets as $_sidebar_id => $_value) {
				if( array_key_exists($_sidebar_id,$_sidebars_widgets_data_for_import) ) {
					$_sidebars_widgets[$_sidebar_id] = array ();
					foreach ( $_sidebars_widgets_data_for_import[$_sidebar_id] as $_widget_id => $_widget_settings ) {
						array_push($_sidebars_widgets[$_sidebar_id], $_widget_id);
					}
				}
			}
			update_option('sidebars_widgets',$_sidebars_widgets);

			/**
			 * Scan and import options settings for each widget added
			 */
			foreach ($_sidebars_widgets_data_for_import as $_sidebar_id => $_widgets_data) {
				foreach ($_widgets_data as $_widget_id => $_widget_settings) {
					self::set_sidebar_widget_options($_widget_id,$_widget_settings);
				}
			}
		}

		/**
		 * Gets the specific common site settings data.
		 *
		 * - posts_per_page
		 */
		protected static function import_common_site_settings_data () {
			// set import data
			if(isset(self::$site_data['common_site_settings'])) {
				$_site_settings_data = self::$site_data['common_site_settings'];
			} else {
				return FALSE;
			}

			foreach ($_site_settings_data as $_key => $_value) {
				update_option($_key,$_value);
			}
		}

		/**
		 * Import navigation data
		 *
		 * Array structure
		 * 		- numbered key index
		 * 			- Menu set data
		 * 			- ...
		 * 			- ...
		 * 			- "menu_items" key index
		 * 				- menu items in numbered array
		 *
		 * 	@uses       TM_Import::$nav_menu_translation_table
		 */
		protected static function import_navigation_data () {
			// set import data
			if(isset(self::$site_data['navigation'])) {
				$_nav_menu_data_for_import = self::$site_data['navigation'];
			} else {
				return FALSE;
			}

			/**
			 * Scan for navigation sets and navigation items.
			 */
			foreach ($_nav_menu_data_for_import as $_key => $_value) {
				/**
				 * nav_menu taxonomy (menu set)
				 * wp_update_term is used to override any existing terms with the same slug
				 * If a nav_menu term with the same name exists, ignored.
				 * term_taxonomy_id is not used because term_taxonomy_id is a unique ID for the term + taxonomy pair,
				 * while term_id is the ID of a term in the terms table.
				 */
				wp_delete_nav_menu($_value['slug']);
				$_nav_menu_id = wp_create_nav_menu($_value['name']);
				$_updated_term = wp_update_term( $_nav_menu_id, 'nav_menu',
					array(
						'name' => $_value['name'],
						'slug' => $_value['slug'],
						'term_group' => $_value['term_group'],
						'description' => $_value['description'],
						'parent' => $_value['parent'],
						'term_id' => $_value['term_id']
					)
				);

				if(is_array($_updated_term)) {
					self::$nav_menu_translation_table[$_value['term_id']] = $_updated_term['term_id'];
				}

				// nav_menu_item post type (menu item)
				if (array_key_exists('menu_items', $_value) && !empty($_value['menu_items'])) {
					foreach ( $_value['menu_items'] as $_index_num => $_menu_item ) {
						// force delete a post with the id once
						wp_delete_post($_menu_item['db_id'],TRUE);
						// insert a post with the db_id to override.
						$_nav_menu_item_id = wp_insert_post(
							array(
								'post_title' => $_menu_item['title'], // required
								'post_content' => '', // required
								'guid' => $_menu_item['guid'],
								'import_id' => $_menu_item['db_id'],
								'post_status' => 'publish',
								'post_type' => 'nav_menu_item',
							)
						);
						// then populate the rest of data
						$_args = array(
							// 'menu-item-db-id'       => $_menu_item['db_id'],
							'menu-item-object-id'   => $_menu_item['object_id'],
							'menu-item-object'      => $_menu_item['object'],
							'menu-item-position'    => $_index_num,
							'menu-item-type'        => $_menu_item['type'],
							'menu-item-title'       => $_menu_item['title'],
							'menu-item-url'         => $_menu_item['url'],
							'menu-item-description' => $_menu_item['description'],
							'menu-item-attr-title'  => $_menu_item['attr_title'],
							'menu-item-target'      => $_menu_item['target'],
							'menu-item-classes'     => implode(' ',$_menu_item['classes']),
							'menu-item-xfn'         => $_menu_item['xfn'],
							'menu-item-status'      => $_menu_item['post_status'],
							'menu-item-position'	=> $_menu_item['menu_order'],
							'menu-item-parent-id'	=> $_menu_item['menu_item_parent'],
						);
						$_nav_menu_item_id = wp_update_nav_menu_item( $_updated_term['term_id'], $_nav_menu_item_id, $_args );

						/**
						 * Attach extra tm nav options
						 * Pay attention to the index key.
						 * Underscore is used for those because the original data is object
						 *  which hyphen cannot be used for the name.
						 */
						if(array_key_exists('menu_item_tm_custom_nav', $_menu_item) && !empty($_menu_item['menu_item_tm_custom_nav'])) {
							update_post_meta($_nav_menu_item_id,'menu-item-tm_custom_nav',$_menu_item['menu_item_tm_custom_nav']);
						}
						if(array_key_exists('menu_item_tm_custom_nav_modal_aux_classes', $_menu_item) && !empty($_menu_item['menu_item_tm_custom_nav_modal_aux_classes'])) {
							update_post_meta($_nav_menu_item_id,'menu-item-tm_custom_nav_modal_aux_classes',$_menu_item['menu_item_tm_custom_nav_modal_aux_classes']);
						}
					}
				}
			}

			/**
			 * Register menu locations.
			 *
			 * @uses       TM_Export::$site_data['customizer']['nav_menu_locations']	nav_menu_locations in Customizer settings
			 */
			$_nav_menu_locations = self::$site_data['customizer']['nav_menu_locations'];
			if(is_array($_nav_menu_locations)) {
				foreach ($_nav_menu_locations as $_key => $_value) {
					$_nav_menu_locations[$_key] = (array_key_exists($_value,self::$nav_menu_translation_table)) ? self::$nav_menu_translation_table[$_value] : 0;
				}
				set_theme_mod('nav_menu_locations', $_nav_menu_locations);
			}
		}

		/**
		 * Find a given widget in a given sidebar and return its settings.
		 *
		 * https://www.flynsarmy.com/2015/06/retrieving-wordpress-sidebar-widget-options/
		 *
		 * Example usage:
		 * $options = [];
		 * try {
		 *    $options = get_sidebar_widget_options('sidebar-1', 'recent-comments');
		 * } catch (Exception $e) {}
		 *
		 * @param $sidebar_id    The ID of the sidebar. Defined in your register_sidebar() call
		 * @param $widget_type   Widget type specified in register_sidebar()
		 * @return array         Saved options
		 * @throws Exception     "Widget not found in sidebar" or "Widget has no saved options"
		 */
		private static function set_sidebar_widget_options($widget_id,$widget_settings) {
			// regexp to separate between id and type
			$_match_return = preg_match("/^(?P<widget_type>.*?)\-(?P<widget_id>\d+)$/", $widget_id, $_matches);
			if($_match_return !== 1) return FALSE;
			// get id
			$_widget_type = $_matches['widget_type'];
			$_widget_id = $_matches['widget_id'];
			// get settings
			$_widget_settings = get_option('widget_'.$_widget_type);
			// just in case that the data is corrupt. initialize if it is not in a right shape.
			if(!is_array($_widget_settings)) $_widget_settings = array();
			// set data
			$_widget_settings[$_widget_id] = $widget_settings;
			// write updated data
			update_option('widget_'.$_widget_type,$_widget_settings);
		}

		/**
		 * Media Library / attachment
		 *
		 * @uses       <element_ref> (description)
		 * @uses       TM_Import::$post_thumbnail_id
		 */
		protected static function import_attachments () {
			// set import data
			if(isset(self::$site_data['attachments'])) {
				$_attachments = self::$site_data['attachments'];
			} else {
				return FALSE;
			}

			// loop through each
			foreach ($_attachments as $_key => $_attachment_data) {
				// remove file
				self::_delete_any_post_with_title('attachment',$_attachment_data['post_title']);
				// download
				self::_download_and_setup_attachment_files($_attachment_data);
			}

			// translate thumb ids
			foreach( self::$post_thumbnail_id as $_post_id => $_thumbnail_id ) {
				if(array_key_exists($_thumbnail_id,self::$thumbnail_id_translation_table)) {
					$_new_thumbnail_id = self::$thumbnail_id_translation_table[$_thumbnail_id];
					set_post_thumbnail($_post_id,$_new_thumbnail_id);
				}
			}
		}

		/**
		 * Downloads and setup attachment files.
		 *
		 * @param      array  $_attachment_data  The single attachment data
		 */
		private static function _download_and_setup_attachment_files($_attachment_data) {
			// Download
			$_upload_result = self::_fetch_remote_file($_attachment_data['attachment_url'], $_attachment_data['post_date']);

			// Register the downloaded file
			if($_upload_result['error'] === FALSE) {
				/** remove if a post with the attachment id exists */
				wp_delete_post($_attachment_data['ID'],TRUE);
				/** update and prepare attachement data for wp_insert_attachment() */
				// guid
				$_attachment_data['guid'] = $_upload_result['url'];
				// backup
				$_old_attachment_id = $_attachment_data['ID'];
				// import id (suggestive id)
				$_attachment_data['import_id'] = $_attachment_data['ID'];
				// remove
				unset($_attachment_data['ID']);
				// remove the attachment_url bcause it is not necessary any more here.
				unset($_attachment_data['attachment_url']);

				/**
				 * Insert post and set meta data, attachment_url.
				 */
				$_post_id = wp_insert_attachment( $_attachment_data,$_upload_result['file'] );
				// record into the translation table
				self::$thumbnail_id_translation_table[$_old_attachment_id] = $_post_id;
				// update file location
				wp_update_attachment_metadata( $_post_id, wp_generate_attachment_metadata( $_post_id,$_upload_result['file'] ) );
			}
		}

		/**
		 * Attempt to download a remote file attachment
		 *
		 * From https://github.com/WordPress/wordpress-importer/blob/master/wordpress-importer.php
		 *
		 * @uses       wp_upload_bits()
		 *
		 * @param 		string 		$url 			URL of item to fetch
		 * @param      	string 		$post_date 		Post date used for wp_upload_bits()
		 *
		 * @return array|FALSE Local file location details on success, FALSE otherwise
		 */
		public static function _fetch_remote_file( $url, $post_date = '') {
			/**
			 * Duplication prevention.
			 */
			// extract the file name and extension from the url
			$_file_name = basename( $url );
			// Full path to the upload file. Used to avoid duplication.
			$_upload_file_full_path = wp_upload_dir($post_date);
			$_upload_file_full_path = $_upload_file_full_path['path'].'/'.$_file_name;
			// remove file if exists
			if(file_exists($_upload_file_full_path)) {
				@unlink( $_upload_file_full_path );
			}
			/**
			 * Make sure that ZIP is added to the allowed fily type.
			 *
			 * @see get_allowed_mime_types();
			 */
			add_filter('upload_mimes', function($mime_types) {
				$mime_types['zip'] = 'application/zip';
				return $mime_types;
			}, 20);

			/**
			 * get placeholder file in the upload dir with a unique, sanitized filename
			 */
			$_upload = wp_upload_bits( $_file_name, 0, '', $post_date );

			// Error handling
			if ( $_upload['error'] ) return FALSE;

			/**
			 * fetch the remote url and write it to the placeholder file
			 */
			$_remote_response = wp_safe_remote_get( $url, array(
				'timeout' => 800,
				'stream' => true,
				'filename' => $_upload['file'],
			) );
			$_headers = wp_remote_retrieve_headers( $_remote_response );
			// Error handling
			if ( ! $_headers ) {
				@unlink( $_upload['file'] );
				// return new WP_Error( 'import_file_error', __('Remote server did not respond', 'wordpress-importer') );
				return FALSE;
			}

			$_remote_response_code = wp_remote_retrieve_response_code( $_remote_response );

			/**
			 * Error handlings after file transfer
			 */

			// make sure the fetch was successful
			if ( $_remote_response_code != '200' ) {
				@unlink( $_upload['file'] );
				// return new WP_Error( 'import_file_error', sprintf( __('Remote server returned error response %1$d %2$s', 'wordpress-importer'), esc_html($_remote_response_code), get_status_header_desc($_remote_response_code) ) );
				return FALSE;
			}

			$_filesize = filesize( $_upload['file'] );
			if ( isset( $_headers['content-length'] ) && $_filesize != $_headers['content-length'] ) {
				@unlink( $_upload['file'] );
				// return new WP_Error( 'import_file_error', __('Remote file is incorrect size', 'wordpress-importer') );
				return FALSE;
			}

			if ( 0 == $_filesize ) {
				@unlink( $_upload['file'] );
				// return new WP_Error( 'import_file_error', __('Zero size file downloaded', 'wordpress-importer') );
				return FALSE;
			}

			$_max_size = (int) apply_filters( 'import_attachment_size_limit', 0 );
			if ( ! empty( $_max_size ) && $_filesize > $_max_size ) {
				@unlink( $_upload['file'] );
				// return new WP_Error( 'import_file_error', sprintf(__('Remote file is too large, limit is %s', 'wordpress-importer'), size_format($_max_size) ) );
				return FALSE;
			}

			return $_upload;
		}

		/**
		 * Delete attachent file by name
		 *
		 * @param      <type>  $title  The title
		 */
		private static function _delete_any_post_with_title($post_type,$title) {
			$_args = array(
				'posts_per_page' => -1,
				'post_type' => $post_type,
				'post_status' => array('inherit','publish'), // attachment is set to inherit
				'title' => $title // WP_Query uses key, title instead of post_title
			);
			$_the_query = new \WP_Query($_args);
			$_posts = $_the_query->posts;
			foreach($_posts as $_post) {
				if($post_type === 'attachment') {
					$_result = wp_delete_attachment($_post->ID,TRUE);
				} else {
					$_result = wp_delete_post($_post->ID,TRUE);
				}
			}
		}

		/**
		 * Gets the file relative path manually.
		 * This function is here for referential and debug purpose only and is not to be used.
		 *
		 * @param      string  $attachment_url  The attachment url
		 *
		 * @return     string  The file relative path processed manually.
		 */
		private static function get_file_relative_path_manually($attachment_url) {
			/** Get urls */
			$_wordpress_upload_dir = wp_upload_dir();
			$_wordpress_upload_dir = $_wordpress_upload_dir['baseurl'];
			$_attachment_file_source_url = $attachment_url;
			$_attachment_file_relative_path = preg_replace("/.*wp-content\/uploads(.*)$/", "$1", $_attachment_file_source_url);
			return $_attachment_file_relative_path;
		}

		/**
		 * Output data as JSON text and exit.
		 * This function is here for referential and debug purpose only and is not to be used.
		 *
		 * @see        http://jsoneditoronline.org/ Use for debug.
		 *
		 * @param      array  $fileContents  The file contents. This array is then converted into JSON string and will be output as a file.
		 */
		protected static function send_complete_signal_and_exit () {
			$json_contents = array('response'=>TRUE,'message'=>'');
			header( "Content-Type: application/json" );
			echo json_encode($json_contents);
			die();
		}

	}
}