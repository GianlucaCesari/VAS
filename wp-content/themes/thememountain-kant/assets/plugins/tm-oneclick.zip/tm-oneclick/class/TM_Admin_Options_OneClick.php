<?php
namespace ThemeMountain {
    /**
     * CMB Tabbed Theme Options
     *
     * @package ThemeMountain
     * @subpackage theme-plugin
     * @since 1.0
     */
    class TM_Admin_Options_OneClick
    {
        /**
         * variables for plugin
         */
        public static $local_plugin_dir;
        public static $local_plugin_dir_uri;
        public static $plugin_basename;

        /**
         * Default Option key
         * @var string
         */
        private static $key = 'themeMountain_oneclick';

        /**
         * Array of metaboxes/fields
         * @var array
         */
        protected static $option_metabox = array();
        public static $option_metabox_haystack = array();

        /**
         * Options Page title
         * @var string
         */
        protected static $title = '';

        /**
         * Options Tab Pages
         * @var array
         */
        protected static $options_pages = array();

        /**
         * Cached theme options used in self::tm_admin_option().
         *
         * @var        array
         */
        private static $cached_theme_options = array();

        /**
         * Constructor
         * @since 0.1.0
         */
        public function __construct($_class_settings = array())
        {
            self::$local_plugin_dir = $_class_settings['local_plugin_dir'];
            self::$local_plugin_dir_uri = $_class_settings['local_plugin_dir_uri'];
            self::$plugin_basename = $_class_settings['plugin_basename'];
            
            // Set our title
            self::$title = esc_html__('ThemeMountain OneClick Import', 'thememountain-oneclick');

            // hooks
            add_action('admin_init', array('ThemeMountain\\TM_Admin_Options_OneClick', 'init_admin'));
            add_action('admin_menu', array('ThemeMountain\\TM_Admin_Options_OneClick', 'add_options_page'));
            add_filter("plugin_action_links_" . self::$plugin_basename, array('ThemeMountain\\TM_Admin_Options_OneClick', 'add_settings_link_to_plugin_description'));
            // admin functions
        }

        /**
         * Public getter method for retrieving protected/private variables
         * @since  0.1.0
         * @param  string  $field Field to retrieve
         * @return mixed          Field value or exception is thrown
         */
        public function __get($field)
        {
            // Allowed fields to retrieve
            switch ($field) {
                case 'key':
                    return self::$key;
                    break;
                case 'title':
                    return self::$title;
                    break;
                case 'options_pages':
                    return self::$options_pages;
                    break;
                case 'option_metabox':
                    return self::option_fields();
                    break;
            }
            throw new Exception('Invalid property: ' . $field);
        }

        /**
         * Register our setting tabs to WP
         * @since  0.1.0
         */
        public static function init_admin()
        {
            $option_tabs = self::option_fields();
            foreach ($option_tabs as $index => $option_tab) {
                register_setting($option_tab['id'], $option_tab['id']);
            }
        }

        /**
         * Add menu options page
         * @since 0.1.0
         */
        public static function add_options_page()
        {
            $option_tabs = self::option_fields();
            /** loop through and construct the array */
            foreach ($option_tabs as $index => $option_tab) {
                if ($index == 0) {
                    //Link admin menu to first tab
                    array_push(self::$options_pages, add_menu_page(self::$title, self::$title, 'manage_options', $option_tab['id'], array('ThemeMountain\\TM_Admin_Options_OneClick', 'admin_page_display')));
                    //Duplicate menu link for first submenu page
                    add_submenu_page($option_tabs[0]['id'], self::$title, $option_tab['title'], 'manage_options', $option_tab['id'], array('ThemeMountain\\TM_Admin_Options_OneClick', 'admin_page_display'));
                    array_push(self::$option_metabox_haystack, 'toplevel_page_' . $option_tab['id']);
                } else {
                    array_push(self::$options_pages, add_submenu_page($option_tabs[0]['id'], self::$title, $option_tab['title'], 'manage_options', $option_tab['id'], array('ThemeMountain\\TM_Admin_Options_OneClick', 'admin_page_display')));
                    array_push(self::$option_metabox_haystack, 'thememountain_page_' . $option_tab['id']);
                }
            }
            // for the ajax nonce and script
            add_action('admin_enqueue_scripts', array('ThemeMountain\\TM_Admin_Options_OneClick', 'tm_admin_enqueue_scripts'));
        }

        public static function tm_admin_enqueue_scripts($hook)
        {
            if ($hook == 'toplevel_page_tm_oneclick_concepts') {
                // javascript
                wp_enqueue_script('lazyload', self::$local_plugin_dir_uri . '/admin/assets/js/lazyload.min.js', array('jquery'), null);
                wp_enqueue_script('isotope', self::$local_plugin_dir_uri . '/admin/assets/js/isotope.js', array('jquery'), null);
                wp_enqueue_script('tm_admin_oneclick_concepts', self::$local_plugin_dir_uri . '/admin/assets/js/tm_admin_oneclick_concepts.js', array('lazyload', 'isotope', 'jquery'), null);
                // Find the current theme id
                if (method_exists('ThemeMountain\TM_ThemeMountain', 'get_theme_id')) {
                    $_theme_id = TM_ThemeMountain::get_theme_id();
                } else {
                    $_theme_id = '';
                }
                wp_localize_script('tm_admin_oneclick_concepts', 'tm_ajax_oneclick', array('tm_ajax_oneclick_nonce' => wp_create_nonce('TM_Ajax_OneClick'), 'current_template_id' => $_theme_id));
                // CSS
                wp_enqueue_style('tm_admin_oneclick_concepts', self::$local_plugin_dir_uri . '/admin/assets/css/tm_admin_oneclick_concepts.css');
            }
        }

        /**
         * Admin page markup. Mostly handled by CMB
         * @since  0.1.0
         */
        public static function admin_page_display()
        {
            // compatibility check
            if (!function_exists('cmb2_metabox_form')) {
                echo "<div>CMB2 plugin is required.</div>";
                return false;
            }
            //get all option tabs
            $_option_tabs = self::option_fields();
            $_current_page_index = array_search(self::$key, self::$option_metabox_haystack);
            /** sort by weight */
            usort($_option_tabs, function ($a, $b) {
                return $a['weight'] - $b['weight'];
            });

            /** tab forms */
            ?>
			<div class="wrap cmb_options_page tm-oneclick <?php echo self::$key; ?>">
				<div class="wrapper-inner">

					<!-- Header -->
					<header class="header header-relative">
						<div class="header-inner">
							<div class="row full-width nav-bar">
								<div class="column width-12 nav-bar-inner">
									<div class="logo">
										<div class="logo-inner">
											<img src="<?php echo self::$local_plugin_dir_uri ?>/admin/assets/images/logo.png" alt="TM Logo" width="200">
										</div>
									</div>
								</div>
							</div>
						</div>
					</header>
					<!-- Header End -->

					<!-- Content -->
					<div class="content clearfix">
						<?php cmb2_metabox_form(
                $_option_tabs[$_current_page_index],
                self::$key,
                array(
                    'save_button' => '',
                    'form_format' => '<form class="cmb-form" method="post" id="%1$s" enctype="multipart/form-data" encoding="multipart/form-data"><input type="hidden" name="object_id" value="%2$s">%3$s</form>',
                ));
            ?>
					</div>
				</div>
			</div>
			<?php
}

        /**
         * Defines the theme option metabox and field configuration
         *
         * @since  1.0
         * @access     public
         * @uses        ThemeMountain\WP_ThemeServices::tm_admin_option_option_fields() Theme files have the function to send available theme style names and ids to the admin panel.
         *
         * @return     array $option_metabox
         */
        public static function option_fields()
        {

            // Only need to initiate the array once per page-load
            if (!empty(self::$option_metabox)) {
                return self::$option_metabox;
            }

            // load a json file that contains the menu structure.
            require self::$local_plugin_dir . 'admin/option_menu_fields.php';

            // return the array
            return self::$option_metabox;
        }

        /**
         * Admin functions
         */

         /**
          * Add a direct link to the admin page
          *
          * @param array $links
          * @return array
          */
        public static function add_settings_link_to_plugin_description($links){
            $settings_link = '<a href="options-general.php?page=tm_oneclick_concepts">' . __('ThemeMountain OneClick Showcase','thememountain-oneclick') . '</a>';
            array_push($links, $settings_link);
            return $links;
        }
    }
}