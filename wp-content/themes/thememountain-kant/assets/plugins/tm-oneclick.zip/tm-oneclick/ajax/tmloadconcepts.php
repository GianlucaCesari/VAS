<?php
namespace ThemeMountain;

if (is_user_logged_in() !== TRUE) {
    $ajaxResponseArray = TM_Ajax_OneClick::constructAjaxResponseArray(FALSE, '');
} else {
    // Find the current theme id
    if (method_exists('ThemeMountain\TM_ThemeMountain','get_theme_id')) {
        $_theme_id = TM_ThemeMountain::get_theme_id();
    } else {
        $_theme_id = '';
    }

	$serverResponse = wp_remote_post('https://update.thememountain.com/oneclick/concepts-' . $_theme_id . '.json');

    if($serverResponse['response']['code'] == 404) {
        if(!empty($_theme_id)) {
            $_error_message = esc_html__('Please check up ThemeMountain Facebook page to see if there is any uddate information.','thememountain-oneclick');
        } else {
            $_error_message = esc_html__('This theme is not compatible with ThemeMountain OneClick.','thememountain-oneclick');
        }
        $ajaxResponseArray = TM_Ajax_OneClick::constructAjaxResponseArray(FALSE, $_error_message);
    } else if (is_array($serverResponse)) {
        $ajaxResponseArray = TM_Ajax_OneClick::constructAjaxResponseArray(TRUE, json_decode($serverResponse['body']));
    } else {
        $ajaxResponseArray = TM_Ajax_OneClick::constructAjaxResponseArray(FALSE, '');
    }
}
