<?php
namespace ThemeMountain;

// remove time limit
set_time_limit(1000);

if ( is_user_logged_in() !== TRUE ) {
	$ajaxResponseArray = TM_Ajax_OneClick::constructAjaxResponseArray(FALSE,'User not logged in');
} else if (!isset($_POST['concept_id'])) {
	$ajaxResponseArray = TM_Ajax_OneClick::constructAjaxResponseArray(FALSE,'Conceept ID not set');
} else if (!class_exists('\\ZipArchive')) {
	$ajaxResponseArray = TM_Ajax_OneClick::constructAjaxResponseArray(FALSE,'ThemeMountain OneClick requires zip extension of PHP on your server to be enabled.<br>Please consult with your hosting company to enable it.');
} else {
	// load class
	if(!class_exists('\\ThemeMountain\\TM_Import')) {
		include_once( TM_Ajax_OneClick::$local_plugin_dir . 'class/TM_Import.php');
	}

	$serverResponse = TM_Import::_fetch_remote_file('https://update.thememountain.com/oneclick/site_data/'.$_POST['concept_id'].'.json.zip');

	if($serverResponse['error'] === FALSE) {
		// system variable for temporary folder
		$tmporary_dir = ini_get('upload_tmp_dir') ? rtrim(ini_get('upload_tmp_dir'), '/') : sys_get_temp_dir();
		// get file extension
		$_file_path = $serverResponse['file'];
		$_file_name = basename($_file_path);
		$_file_extension = pathinfo($_file_name, PATHINFO_EXTENSION);

		// read data from file
		switch ($_file_extension) {
			case 'zip':
				$_zip = new \ZipArchive();
				if($_zip->open($_file_path) == TRUE) {
					$_archive_filenames = array();
					for ($_i = 0; $_i < $_zip->numFiles; $_i++) {
						array_push($_archive_filenames,$_zip->getNameIndex($_i));
					}
					// extract to temp dir
					$_zip->extractTo($tmporary_dir);
					// scan files
					for ($_i = 0; $_i < count($_archive_filenames); $_i++) {
						$_this_file_name = $_archive_filenames[$_i];
						if(
							strpos($_this_file_name,'_') !==0 &&
							pathinfo($_this_file_name, PATHINFO_EXTENSION) === 'json'
						) {
							break;
						} else {
							$_this_file_name = '';
						}
					}

					$_zip->close();

					if(!empty($_this_file_name)) {
						$_file_content = file_get_contents($tmporary_dir.'/'.$_this_file_name);
						$_file_content = json_decode($_file_content, TRUE);
					}
				}
				break;
			case 'json':
				$_file_content = file_get_contents($_file_path);
				$_file_content = json_decode($_file_content, TRUE);
				break;
			default:
				$_file_content = NULL;
				break;
		}
		@unlink($_file_path);

		// import
		if(!is_null($_file_content)) {
			if(!class_exists('\\ThemeMountain\\TM_Import_OneClick')) {
				include_once( TM_Ajax_OneClick::$local_plugin_dir . 'class/TM_Import_OneClick.php');
			}
			$_import_results = TM_Import_OneClick::import_site_contents_and_options($_file_content);
			$ajaxResponseArray = TM_Ajax_OneClick::constructAjaxResponseArray(TRUE,$_import_results);
		} else {
			$ajaxResponseArray = TM_Ajax_OneClick::constructAjaxResponseArray(FALSE,'File could not be uploaded.');
		}
	} else {
		$ajaxResponseArray = TM_Ajax_OneClick::constructAjaxResponseArray(FALSE,'Failed to download data file.');
	}
}


