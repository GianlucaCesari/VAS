<?php
namespace ThemeMountain;

// load class
	if(!class_exists('\\ThemeMountain\\TM_CartNavMenu')) {
		include_once( TM_Ajax_Import::$local_plugin_dir . 'class/TM_CartNavMenu.php');
	}

// update
	$_result = TM_CartNavMenu::get_current_cart();

$ajaxResponseArray = TM_Ajax_Commerce::constructAjaxResponseArray(TRUE,$_result);