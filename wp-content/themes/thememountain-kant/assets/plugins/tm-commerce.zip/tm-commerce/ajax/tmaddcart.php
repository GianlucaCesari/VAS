<?php
namespace ThemeMountain;
// tmaddcart
// load class
	if(!class_exists('\\ThemeMountain\\TM_CartNavMenu')) {
		include_once( TM_Ajax_Import::$local_plugin_dir . 'class/TM_CartNavMenu.php');
	}

if(isset($_POST['cart_item'])) {
	$_cart_item = json_decode(stripslashes($_POST['cart_item']),TRUE);
	$_result = TM_CartNavMenu::add_item_to_cart($_cart_item);
	$ajaxResponseArray = TM_Ajax_Commerce::constructAjaxResponseArray(TRUE,$_result);
} else {
	$ajaxResponseArray = TM_Ajax_Commerce::constructAjaxResponseArray(FALSE,'');
}