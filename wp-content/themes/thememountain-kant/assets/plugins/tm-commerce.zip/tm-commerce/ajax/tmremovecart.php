<?php
namespace ThemeMountain;
// tmaddcart
// load class
	if(!class_exists('\\ThemeMountain\\TM_CartNavMenu')) {
		include_once( TM_Ajax_Import::$local_plugin_dir . 'class/TM_CartNavMenu.php');
	}

if(isset($_POST['remove_item'])) {
	$_result = TM_CartNavMenu::remove_item_from_cart($_POST['remove_item']);
	$ajaxResponseArray = TM_Ajax_Commerce::constructAjaxResponseArray(TRUE,$_result);
} else {
	$ajaxResponseArray = TM_Ajax_Commerce::constructAjaxResponseArray(FALSE,'');
}