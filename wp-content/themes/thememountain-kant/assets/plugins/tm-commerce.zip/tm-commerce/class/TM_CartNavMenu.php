<?php
namespace ThemeMountain {
	/**
	 * Adds cart nav menu support.
	 *
	 * https://wppatrickk.com/woocommerce-add-cart-ajax-single-product-page/
	 *
	 * @package ThemeMountain
	 * @subpackage Core/tm-commerce
	 * @since 1.0
	 */
	class TM_CartNavMenu {
		/**
		 * Properties for plugin
		*/
		public static $local_plugin_dir;
		public static $local_plugin_dir_uri;

		/**
		 * Constructor
		 */
		public function __construct( $_class_settings = array () ) {
			self::$local_plugin_dir = $_class_settings['local_plugin_dir'];
			self::$local_plugin_dir_uri = $_class_settings['local_plugin_dir_uri'];

			/**
			 * Init ThemeMountain Ajax Cart Nav Menu
			 */
			if(!is_admin()) {
				add_action( 'init', ['ThemeMountain\\TM_CartNavMenu','setup_hooks_for_car_nav_menu'] );
			}

			/**
			 * Add ThemeMountain Admin options tab for tm-commerce. This is always required to ensure the default value is set.
			 * tm_admin_option_option_fields is a hook found in TM_admin::option_fields() of tm-plugin.
			 */
			add_filter('tm_admin_option_option_fields',['ThemeMountain\\TM_CartNavMenu','on_tm_admin_option_option_fields']);
		}

		/**
		 * Methods
		 */

		/**
		 * Adds additional option tab for the TM Options panel.
		 *
		 * @param      <array>  $option_metabox  The option metabox data fields
		 *
		 * @return     <array>  returns $option_metabox otherwise TM_Admin will cause error.
		 */
		public static function on_tm_admin_option_option_fields($option_metabox) {
			// making sure that supported version of WOOCOMMERCE is activated.
			if( defined('WOOCOMMERCE_VERSION') && version_compare( WOOCOMMERCE_VERSION, '2.7', '>=' )) :

			$option_metabox = array_merge($option_metabox,
				array(
					array (
						'id' => 'tm_cart_nav_menu',
						'title' => esc_html__('Cart Nav Menu','thememountain-commerce'),
						'weight' => 9,
						'show_on' =>
						array (
							'key' => 'options-page',
							'value' =>
							array (
								'tm_cart_nav_menu',
								),
							),
						'show_names' => true,
						'fields' =>
							array (
								array (
									'name' => esc_html__('Ues ThemeMountain Ajax Cart Nav Menu','thememountain-commerce'),
									'id' => 'tm_use_ajax_cart_nav_memu',
									'type' => 'select',
									'show_option_none' => false,
									'default' => '1',
									'options' =>
									array (
										'0' => esc_html__('No','thememountain-commerce'),
										'1' => esc_html__('Yes','thememountain-commerce'),
										),
								),
							)
					)
				)
			);

			endif;

			return $option_metabox;
		}

		/**
		 * Cart Nav Menu Frontend handlings
		 */

		/**
		 * Add an action hook for TM_CartNavMenu functions.
		 */
		public static function setup_hooks_for_car_nav_menu() {
			// requires ThemeMountain Themes
			if(!class_exists('\\ThemeMountain\\TM_ThemeMountain')) {
				return FALSE;
			}

			$_tm_use_ajax_cart_nav_memu = TM_ThemeServices::tm_admin_option('tm_cart_nav_menu','tm_use_ajax_cart_nav_memu');

			// See if the option is enabled. Note: default is enabled.
			if( $_tm_use_ajax_cart_nav_memu === '0' ) return FALSE;

			// WooCommerce specific: check if woocommerce cart object is actually loaded
			global $woocommerce;
			if (empty($woocommerce) || !is_object($woocommerce) || !isset($woocommerce->cart) || !is_object($woocommerce->cart)) {
				return FALSE;
			}

			/**
			 * Cart Nav Menu Script enqueue for ajax.
			 */
			add_action( 'wp_enqueue_scripts', ['ThemeMountain\\TM_CartNavMenu','enqueue_cartnavmenu_files'] , 999);

			/**
			 * Add Cart to the menu nav.
			 */
			add_action( 'tm_nav_buttons_before', ['ThemeMountain\\TM_CartNavMenu','output_initial_cart_html_markup'] ) ;
		}

		/**
		 * Enqueue ajax javascript for this custom woocommerce template.
		 *
		 * @see        TM_CartNavMenu::on_tm_admin_option_option_fields()
		 * @see        The tm_use_ajax_cart_nav_memu admin option
		 */
		public static function enqueue_cartnavmenu_files() {
			// disable woocommerce native add to cart ajax support
			// wp_deregister_script('wc-add-to-cart');
			// add custom ajax cart support
			wp_enqueue_script( 'tm-commerce', plugins_url( 'assets/js/tm-commerce.js', dirname(__FILE__) ), array('jquery'));
			wp_localize_script('tm-commerce','tm_ajax_commerce',array('ajaxurl' => admin_url( 'admin-ajax.php' ),'nonce' => wp_create_nonce('TM_Ajax_Commerce')));

		}

		/**
		 * Shows cart's html markup for initial state when page is displayed.
		 *
		 * @uses       TM_CartNavMenu::get_cart_contents_count()
		 * @uses       TM_CartNavMenu::get_cart_overview_html()
		 *
		 * @see        tm_nav_buttons_before hook in the theme.
		 * @see        overlay_navigation.php in the theme (supported products only)
		 */
		public static function output_initial_cart_html_markup(){
			if(!class_exists( 'WooCommerce' )) return FALSE;
			// markup construction
			$_cart_html_markup = '<li class="tm-commerce-ajax-cart">
					<!-- Dropdown Cart Overview -->
					<div class="dropdown">
					<a href="#" class="nav-icon cart button no-page-fade"><span class="cart-indication"><span class="icon-shopping-cart"></span> <span class="badge">'.self::get_cart_contents_count().'</span></span></a>
					<ul class="dropdown-list custom-content cart-overview">'.self::get_cart_overview_html().'</ul>
					</div></li>';

			echo ($_cart_html_markup);
		}

		/**
		 * Returns cart list in html as well as item counter. Used for Ajax responses.
		 *
		 * @uses $woocommerce
		 * @uses WC_Cart class and its method, get_cart_contents_count().
		 *
		 * @see Ajax command: tmupdatecart
		 * @see TM_CartNavMenu::add_item_to_cart()
		 * @see TM_CartNavMenu::remove_item_from_cart()
		 *
		 * @return array cart_contents_count and cart_overview_html
		 */
		public static function get_current_cart(){
			$_cart_contents_count = self::get_cart_contents_count();
			return array(
				'cart_contents_count' => $_cart_contents_count,
				'cart_overview_html' => self::get_cart_overview_html()
			);
		}

		/**
		 * Get cart contents count
		 *
		 *
		 * @return Integer
		 */
		public static function get_cart_contents_count(){
			global $woocommerce;
			if (empty($woocommerce->cart)) $woocommerce->cart = new \WC_Cart();
			return $woocommerce->cart->get_cart_contents_count();
		}

		/**
		 * Ajax support functions for Cart Nav Menu
		 */

		/**
		 * Gets the cartesian overview html.
		 * @see        TM_CartNavMenu::get_cart_html_markup()
		 */
		public static function get_cart_overview_html(){
			global $woocommerce;

			/**
			 * Get Items in the cart
			 */
			$_cart_items = '';
			foreach ( WC()->cart->get_cart() as $_cart_item_key => $_cart_item ) {
				$_product   = apply_filters( 'woocommerce_cart_item_product', $_cart_item['data'], $_cart_item, $_cart_item_key );
				$_product_id = apply_filters( 'woocommerce_cart_item_product_id', $_cart_item['product_id'], $_cart_item, $_cart_item_key );

				if ( $_product && $_product->exists() && $_cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $_cart_item, $_cart_item_key ) ) {
					// variables
					$_product_remove = array(
						'car_item_key' => $_cart_item_key,
						'product_id' => esc_attr( $_product_id ),
						'sku' => esc_attr( $_product->get_sku() )
					);
					// product permalink
					$_product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $_cart_item ) : '', $_cart_item, $_cart_item_key );
					// product thumbnail
					$_product_thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $_cart_item, $_cart_item_key );

					// Backorder
					$_product_backorder_notification = ( $_product->backorders_require_notification() && $_product->is_on_backorder( $_cart_item['quantity'] ) ) ? esc_html__( 'Available on backorder', 'thememountain-commerce' ) : '';
					// price
					$_product_price = apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $_cart_item, $_cart_item_key );
					// Meta data
					$_product_meta_data = wc_get_formatted_cart_item_data( $_cart_item , true);
					if(!empty($_product_meta_data)) {
						$_product_meta_data = " - <span class='product-variation'>{$_product_meta_data}</span>";
					}
					// product quantity
					$_product_quantity = apply_filters( 'woocommerce_cart_item_quantity', $_cart_item['quantity'], $_cart_item_key, $_cart_item );
					// product sub total
					$_product_sub_total = apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $_cart_item['quantity'] ), $_cart_item, $_cart_item_key );
					// remove button
					$_remove_item = '<a href="'.esc_url( wc_get_cart_remove_url( $_cart_item_key ) ).'" aria-label="'. esc_html__( 'Remove this item', 'thememountain-commerce' ).'" data-product_id="'.$_product_remove['product_id'].'" data-product_sku="'.$_product_remove['sku'].'" data-cart-item-key="'.$_product_remove['car_item_key'].'" class="remove product-remove icon-cancel no-page-fade"></a>';
					// product item title
					$_product_item_title =  apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $_cart_item, $_cart_item_key );
					// add an item html markup
					$_cart_items .= '<li class="cart-item">
						<a href="'.esc_url( $_product_permalink ).'" class="product-thumbnail">'.$_product_thumbnail.'
						</a><div class="product-details"><a href="'.esc_url( $_product_permalink ).'" class="product-title">'.$_product_item_title.$_product_meta_data.'</a><span class="product-quantity">'.$_product_quantity.' x </span><span class="product-price">'.$_product_price.'</span>'.$_remove_item.' '.$_product_backorder_notification.'</div></li>';
				}
			}

			/**
			 * Get the real total amount.
			 */
			if ($woocommerce->cart->display_cart_ex_tax) {
				$_cart_contents_total = wc_price( $woocommerce->cart->cart_contents_total );
			} else {
				$_cart_contents_total = wc_price( $woocommerce->cart->cart_contents_total + $woocommerce->cart->tax_total );
			}
			$_cart_contents_total = apply_filters( 'woocommerce_cart_contents_total', $_cart_contents_total );

			/**
			 * construct the html for the bottom part
			 *
			 * @var        string
			 */
			$_total_and_buttons = '<li class="cart-subtotal">'.esc_html__('Total','thememountain-commerce').'<span class="amount">'.$_cart_contents_total.'</span></li><li class="cart-actions"><a href="'.wc_get_cart_url().'" class="view-cart mt-10">'.esc_html__('View Cart','thememountain-commerce').'</a><a href="'.wc_get_checkout_url().'" class="checkout button small"><span class="icon-check"></span> '.esc_html__('Checkout','thememountain-commerce').'</a></li>';
			return $_cart_items.$_total_and_buttons;
		}

		/**
		 * Adds an item to cart.
		 *
		 * @see        WC_AJAX::add_to_cart()	woocommerce/includes/class-wc-ajax.php
		 * @see        tmaddcart.php
		 *
		 * @param      array $cart_item
		 */
		public static function add_item_to_cart($cart_item){
			/**
			 * Set ata passed from web browser
			 */
			$_product_id = apply_filters( 'woocommerce_add_to_cart_product_id', absint( $cart_item['product_id'] ) );
			$_variation_id       = empty( $cart_item['variation_id'] ) ? '' : absint( wp_unslash( $cart_item['variation_id'] ) );
			$_quantity          = empty( $cart_item['quantity'] ) ? 1 : wc_stock_amount( $cart_item['quantity'] );

			/**
			 * Prepare blank arrays
			 */
			$_missing_attributes = array();
			$_variations         = array();

  			/**
  			 * Determine variation of ordered product
  			 */
			try {
				$_adding_to_cart     = wc_get_product( $_product_id );

				if ( ! $_adding_to_cart ) {
					return false;
				}

				// If the $_product_id was in fact a variation ID, update the variables.
				if ( $_adding_to_cart->is_type( 'variation' ) ) {
					$_variation_id   = $_product_id;
					$_product_id     = $_adding_to_cart->get_parent_id();
					$_adding_to_cart = wc_get_product( $_product_id );
				}

				// Gather posted attributes.
				$_posted_attributes = array();

				foreach ( $_adding_to_cart->get_attributes() as $_attribute ) {
					if ( ! $_attribute['is_variation'] ) {
						continue;
					}
					$_attribute_key = 'attribute_' . sanitize_title( $_attribute['name'] );

					if ( isset( $cart_item[ $_attribute_key ] ) ) {
						if ( $_attribute['is_taxonomy'] ) {
							// Don't use wc_clean as it destroys sanitized characters.
							$_value = sanitize_title( wp_unslash( $cart_item[ $_attribute_key ] ) );
						} else {
							$_value = html_entity_decode( wc_clean( wp_unslash( $cart_item[ $_attribute_key ] ) ), ENT_QUOTES, get_bloginfo( 'charset' ) ); // WPCS: sanitization ok.
						}

						$_posted_attributes[ $_attribute_key ] = $_value;
					}
				}

				// If no variation ID is set, attempt to get a variation ID from posted attributes.
				if ( empty( $_variation_id ) ) {
					$_data_store   = \WC_Data_Store::load( 'product' );
					$_variation_id = $_data_store->find_matching_product_variation( $_adding_to_cart, $_posted_attributes );
				}

				// Check the data we have is valid.
				$_variation_data = wc_get_product_variation_attributes( $_variation_id );

				foreach ( $_adding_to_cart->get_attributes() as $_attribute ) {
					if ( ! $_attribute['is_variation'] ) {
						continue;
					}

					// Get valid value from variation data.
					$_attribute_key = 'attribute_' . sanitize_title( $_attribute['name'] );
					$_valid_value   = isset( $_variation_data[ $_attribute_key ] ) ? $_variation_data[ $_attribute_key ]: '';

					/**
					 * If the attribute value was posted, check if it's valid.
					 *
					 * If no attribute was posted, only error if the variation has an 'any' attribute which requires a value.
					 */
					if ( isset( $_posted_attributes[ $_attribute_key ] ) ) {
						$_value = $_posted_attributes[ $_attribute_key ];

						// Allow if valid or show error.
						if ( $_valid_value === $_value ) {
							$_variations[ $_attribute_key ] = $_value;
						} elseif ( '' === $_valid_value && in_array( $_value, $_attribute->get_slugs() ) ) {
							// If valid values are empty, this is an 'any' variation so get all possible values.
							$_variations[ $_attribute_key ] = $_value;
						} else {
							wc_add_notice( sprintf( __( 'Invalid value posted for %s', 'woocommerce' ), wc_attribute_label( $_attribute['name'] ) ) );
						}
					} elseif ( '' === $_valid_value ) {
						$_missing_attributes[] = wc_attribute_label( $_attribute['name'] );
					}
				}
				if ( ! empty( $_missing_attributes ) ) {
					wc_add_notice( sprintf( _n( '%s is a required field', '%s are required fields', count( $_missing_attributes ), 'woocommerce' ), wc_format_list_of_items( $_missing_attributes ) ) );
				}
			} catch ( Exception $_e ) {
				wc_add_notice( $_e->getMessage(), 'error' );
				return false;
			}

 			/** validate the order */
 			$_passed_validation = apply_filters( 'woocommerce_add_to_cart_validation', true, $_product_id, $_quantity,$_variations);

  			// blank data for returning results
  			$_result_data = array();

			if ( $_passed_validation && FALSE !== WC()->cart->add_to_cart( $_product_id, $_quantity ,$_variation_id,$_variations ) && 'publish' === $_product_status ) {

				do_action( 'woocommerce_ajax_added_to_cart', $_product_id );

				if ( 'yes' === get_option( 'woocommerce_cart_redirect_after_add' )  ) {
					wc_add_to_cart_message( array( $_product_id => $_quantity ), true );
				}
			} else {
				// If there was an error adding to the cart, redirect to the product page to show any errors
				$_error_data = array(
					'error'       => true,
					'product_url' => apply_filters( 'woocommerce_cart_redirect_after_error', get_permalink( $_product_id ), $_product_id ),
				);
			}

			// get the updated cart content. (the function will )
			$_result_data = self::get_current_cart();

			// add error if applicable
			if(isset($_error_data)) $_result_data = $_result_data + $_error_data;

			/**
			 * Notices
			 */
			$_notices_to_send = array();
			$_all_notices  = WC()->session->get( 'wc_notices', array() );
			$_notice_types = apply_filters( 'woocommerce_notice_types', array( 'error', 'success', 'notice' ) );
			foreach ( $_notice_types as $_notice_type ) {
				if ( wc_notice_count( $_notice_type ) > 0 ) {
					$_notices_to_send[$_notice_type] = array_filter( $_all_notices[ $_notice_type ] );
				}
			}
			// if there is any notice, add those into the result data.
			if(!empty($_notices_to_send)) $_result_data['notices'] = $_notices_to_send;
			// Clear nortices once so that it will not appear in the next page refresh.
			wc_clear_notices();

			return $_result_data;
		}

		/**
		 * Removes an item from cart.
		 */
		public static function remove_item_from_cart($remove_item){
			WC()->cart->remove_cart_item($remove_item);

			// get the updated cart content. (the function will )
			$_result_data = self::get_current_cart();

			return $_result_data;
		}
	}
}