<?php
namespace ThemeMountain {
	/**
	 * Adds woocommerce custom template and support for the woocommerce plugin.
	 * Compatible with Woocommerce verion 2.7 or later.
	 *
	 * @package ThemeMountain
	 * @subpackage Core/tm-commerce
	 * @since 1.0
	 */
	class TM_Commerce {
		/**
		 * Properties for plugin
		*/
		public static $local_plugin_dir;
		public static $local_plugin_dir_uri;

		/**
		 * Register for templates
		 */
		public static $content_product_item_count = 0;

		/**
		 * Constructor
		 */
		public function __construct( $_class_settings = array () ) {
			self::$local_plugin_dir = $_class_settings['local_plugin_dir'];
			self::$local_plugin_dir_uri = $_class_settings['local_plugin_dir_uri'];

			/**
			 * Declare WooCommerce support
			 */
			add_action( 'after_setup_theme', ['ThemeMountain\\TM_Commerce','woocommerce_theme_init'] );

			/** Registers  widgets only if WooCommerce is active */
			add_action( 'widgets_init',['ThemeMountain\\TM_Commerce','widgt_init']);

			/**
			 * WooCommerce Custom Placeholder Image
			 */
			// add_filter( 'woocommerce_placeholder_img_src', ['ThemeMountain\\TM_Commerce','woocommerce_custom_placeholder_image'], 10 );

			/**
			 * Front end set up
			 */
			if(!is_admin()) {
				// Enqueue ThemeMountain CSS for WooCommerce
				add_action( 'wp_enqueue_scripts', ['ThemeMountain\\TM_Commerce','enqueue_tm_commerce_files'] );
				// Intervene by adding filters to include mechanism of WooCommerce so that templates are loaded from this plugin only when the file to be loaded is avialable in the plugin template directory.
				add_action( 'template_redirect', ['ThemeMountain\\TM_Commerce','override_with_custom_template'] );
				// WooCommerce enqueues 3 stylesheets by default. Disable them all.
				// add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );
			}
		}

		/**
		 * Methods
		 */

		/**
		 * Declare WooCommerce support in third party theme
		 */
		public static function woocommerce_theme_init() {
			//  Declare WooCommerce support in third party theme
			add_theme_support( 'woocommerce' );
			/** Remove Template Single Title */
			remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_title', 5);
		}

		/**
		 * Woocommerce custom placeholder image
		 */
		public static function woocommerce_custom_placeholder_image($image_url) {
			// return 'placeholder.png';
		}

		/**
		 * Enqueue css for this custom woocommerce template
		 */
		public static function enqueue_tm_commerce_files() {
			wp_enqueue_style( 'tm-commerce', plugins_url( 'assets/css/tm-commerce.css', dirname(__FILE__) ),array('woocommerce-general'));
		}

		/**
		 * Overrids templates with the ones in this plugin.
		 *
		 * @uses       TM_Commerce::template_include()
		 * @uses       TM_Commerce::wc_get_template_part()
		 * @uses       TM_Commerce::woo_addon_plugin_template()
		 */
		public static function override_with_custom_template () {
			/**
			 * add additional template location
			 */
			add_filter( 'template_include', ['ThemeMountain\\TM_Commerce','template_include'], 100, 1 );
			add_filter( 'wc_get_template_part', ['ThemeMountain\\TM_Commerce','wc_get_template_part'], 1, 3 );
			add_filter( 'woocommerce_locate_template', ['ThemeMountain\\TM_Commerce','woo_addon_plugin_template'], 1, 3 );

			/**
			 * Add tm-commerce custom class to the Wordpress body class.
			 */
			add_filter( 'body_class',['ThemeMountain\\TM_Commerce','wc_body_class']);
		}

		/**
		 * Adds shop sidebar widget if woocommerce plugin is active
		 */
		public static function widgt_init () {
			if(function_exists('is_shop') === TRUE) {
				register_sidebar( array(
					'name'          => esc_html__('WooCommerce Shop Product Archive Sidebar','thememountain-commerce'),
					'id'            => 'shop',
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<h4>',
					'after_title'   => '</h4>',
				) );
			}
		}

		/**
		 * Using template_include hook to modify template_loader hook, so that archive-product is read from the plugin.
		 *
		 * @param      string  $template		Path to template
		 *
		 * @return     string  $template		Path to template
		 */
		public static function template_include( $template ) {
			$_template_path = self::$local_plugin_dir  . 'templates/archive-product.php';
			// Look within passed path within the theme - this is priority
			if( strpos($template,'plugins/woocommerce/templates/archive-product.php') !== FALSE && file_exists( $_template_path) ){
				$template = $_template_path;
			}
			return $template;
		}

		/**
		 * Some of the WooCommerce templates require wc_get_template_part filter hook to be used to override.
		 *
		 * @param      <string>  $template		Path to template
		 * @param      <string>  $slug			The template name
		 * @param      <string>  $name			File name
		 *
		 * @return     <string>  $template		Path to template
		 */
		public static function wc_get_template_part( $template, $slug, $name ) {
			$_template_path = self::$local_plugin_dir  . 'templates/';
			if(!empty($slug)) $_template_path .= $slug."-";
			$_template_path .= $name.".php";
			// Look within passed path within the theme - this is priority
			if( file_exists( $_template_path) ){
				$template = $_template_path;
			}
			return $template;
		}

		/**
		 * Overrides wc_get_template_part to load template parts / fragments to load from this plugin
		 *
		 * @since      3.0.0 (woocommerce)
		 *
		 * @param      <string>  $template			The template
		 * @param      <string>  $template_name		The template name
		 * @param      <string>  $template_path		The template path
		 *
		 * @uses       wc_get_template_part, woocommerce_locate_template filter hooks
		 *
		 * @return     <string>  ( $template )
		 */
		public static function woo_addon_plugin_template( $template, $template_name, $template_path ) {
			global $woocommerce;
			$_template = $template;
			if ( ! $template_path )
				$template_path = $woocommerce->template_url;

			$_plugin_template_path  = self::$local_plugin_dir  . 'templates/';

			// Look within passed path within the theme - this is priority
			$template = locate_template(
				array(
					$template_path . $template_name,
					$template_name
					)
				);

			if( ! $template && file_exists( $_plugin_template_path . $template_name ) ) {
				$template = $_plugin_template_path . $template_name;
			}

			if ( ! $template ) {
				$template = $_template;
			}
			return $template;
		}

		/**
		 * Adds custom body class for tm-commerce
		 *
		 * @param      <array>  $classes  The classes
		 *
		 * @return     <array>  The classes
		 */
		public static function wc_body_class( $classes ) {
			/** It is assumed that WooCommerce plugin is active if is_shop() function exists. */
			if(function_exists('is_shop') === FALSE) return array_unique( $classes );

			/** add classes conditionally */
			$classes = (array) $classes;
			if ( is_shop() ) {
				array_push($classes,'shop');
				array_push($classes,'catalogue-products');
			} else if ( is_product() ) {
				array_push($classes,'shop');
				array_push($classes,'single-product');
			} else if ( is_woocommerce() ) {
				array_push($classes,'shop');
			} elseif ( is_checkout() ) {
				array_push($classes,'shop');
			} elseif ( is_cart() ) {
				array_push($classes,'shop');
			} elseif ( is_account_page() ) {
				array_push($classes,'shop');
			} else {
				// added to all the pages for now.
				array_push($classes,'shop');
			}

			// if ( is_store_notice_showing() ) {
			// 	$classes[] = 'woocommerce-demo-store';
			// }

			return array_unique( $classes );
		}
	}
}