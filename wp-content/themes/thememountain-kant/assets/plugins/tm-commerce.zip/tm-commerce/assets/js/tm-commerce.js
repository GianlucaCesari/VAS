jQuery(document).ready(function($) {
	"use strict";

	var buttons = [
	".add_to_cart_button", // archvie page
	".single_add_to_cart_button", // single post page
	".cart_item a.remove", // remove in cart page
	".woocommerce-cart-form__cart-item a.remove", // in cart page
	"form.woocommerce-cart-form input[name=update_cart]", // cart page
	"input[name=apply_coupon]", // coupon in the cart page
	"a.product-remove", // remove in flyout
	// "input.input-text.qty.text", // in the cart page
	];

// https://wppatrickk.com/woocommerce-add-cart-ajax-single-product-page/
	// disable submit upon click on the add button

	// add events to all the cart related butons
	$(document.body).on('click', buttons.join(','), function(e){
		// e.preventDefault();
		var $_currentTarget = $(e.currentTarget);
		var _class = $_currentTarget.attr('class');
		var _name = $_currentTarget.attr('name');
		if($_currentTarget.hasClass('product-remove')) {
			// this is a remove button in the flyout
			e.preventDefault();
			removeItemFromCart($_currentTarget.attr('href'));
		} else if($_currentTarget.hasClass('single_add_to_cart_button')) {
			// this is an add button in the single post page
			e.preventDefault();
			addItemToCart();
		} else {
			cartupdate_delay();
		}
	});

	function cartupdate_delay() {
		setTimeout(function () { update_cart(); }, 1000);
	}

	/**
	 * Update
	 *
	 * @class      update_cart (name)
	 */
	function update_cart() {
		// prep formdata (the json file )
		var _formData = new FormData(this);
		_formData.append('action','TM_Ajax_Commerce');
		_formData.append('_tm_ajax_commerce_nonce',tm_ajax_commerce.nonce);
		_formData.append('ajax_command','tmupdatecart');

		// send ajax
		$.ajax({
			'url': tm_ajax_commerce.ajaxurl,
			'type': 'POST',
			'dataType': 'json',
			'processData': false, // important
			'contentType': false, // important
			'cache': false,
			'data': _formData
		})
		.done(function( response ) {
			if(response.message) {
				var _cart_data = response.message;
				var $_tm_commerce_ajax_cart = $('.tm-commerce-ajax-cart');
				$_tm_commerce_ajax_cart.find('.cart-indication .badge').text(_cart_data.cart_contents_count);
				$_tm_commerce_ajax_cart.find('.cart-overview').html(_cart_data.cart_overview_html);
			} else {
				console.log('Error in data sent from the server.');
			}
			$('#tm_import_site_file_button').attr('disabled',false);
		})
		.fail(function( response ) {
			console.log('There was an error in handling your request. Please try again later.');
		})
		.always(function( response ) {
		});
	}

	/**
	 * Add
	 */
	function addItemToCart() {
		// vars
		var $_addButton = $('.single_add_to_cart_button');
		// button disabled
		$_addButton.attr('disabled',true);
		// prep formdata (the json file )
		var _formData = new FormData(this);
		_formData.append('action','TM_Ajax_Commerce');
		_formData.append('_tm_ajax_commerce_nonce',tm_ajax_commerce.nonce);
		_formData.append('ajax_command','tmaddcart');

		/**
		 * Add data from form
		 */
		var _variationsFormData = $('.variations_form.cart').serializeArray();
		var _cartItemData = {};
		if(_variationsFormData.length == 0) {
			// single item
			var _quantity = $('input.input-text.qty.text').val();
			var _productID = ($_addButton.val()) ? $_addButton.val() : $('[name="add-to-cart"]').val();
			if(_quantity)_cartItemData.quantity = _quantity;
			_cartItemData.product_id = _productID;
		} else {
			for(var _key in _variationsFormData) {
				_cartItemData[_variationsFormData[_key].name] = _variationsFormData[_key].value;
			}
		}

		_formData.append('cart_item', JSON.stringify(_cartItemData));
		// send ajax
		$.ajax({
			'url': tm_ajax_commerce.ajaxurl,
			'type': 'POST',
			'dataType': 'json',
			'processData': false, // important
			'contentType': false, // important
			'cache': false,
			'data': _formData
		})
		.done(function( response ) {
			if(response.message) {
				var _cart_data = response.message;
				var $_tm_commerce_ajax_cart = $('.tm-commerce-ajax-cart');
				if(_cart_data.error == true) {
					$_addButton.removeClass('added');
				} else {
					$_addButton.addClass('added');
				}
				/**
				 * any kind of messages to display / update
				 * notices : 'error', 'success', 'notice'
				 */
				if(typeof _cart_data.notices != 'undefined') {
					if(typeof _cart_data.notices.success != 'undefined'){
						_showNoticesFromArray('success',_cart_data.notices.success);
					}
					if(typeof _cart_data.notices.notice != 'undefined'){
						_showNoticesFromArray('info',_cart_data.notices.notice);
					}
					if(typeof _cart_data.notices.error != 'undefined'){
						_showNoticesFromArray('warning',_cart_data.notices.error);
					}
				}
				// update the cart info
				if(typeof _cart_data.cart_contents_count != 'undefined') $_tm_commerce_ajax_cart.find('.cart-indication .badge').text(_cart_data.cart_contents_count);
				if(typeof _cart_data.cart_overview_html != 'undefined') $_tm_commerce_ajax_cart.find('.cart-overview').html(_cart_data.cart_overview_html);

				//
			} else {
				console.log('Error in data sent from the server.');
			}
			$('#tm_import_site_file_button').attr('disabled',false);
		})
		.fail(function( response ) {
			console.log('There was an error in handling your request. Please try again later.');
		})
		.always(function( response ) {
			$_addButton.attr('disabled',false);
		});
	}

	/**
	 * Remove
	 */
	function removeItemFromCart(href) {
		var _remove_item = href.match(/remove_item=(.*?)(&|$)/)[1];
		var _wpnonce = href.match(/_wpnonce=(.*?)(&|$)/)[1];

		// prep formdata (the json file )
		var _formData = new FormData(this);
		_formData.append('action','TM_Ajax_Commerce');
		_formData.append('_tm_ajax_commerce_nonce',tm_ajax_commerce.nonce);
		_formData.append('ajax_command','tmremovecart');
		_formData.append('remove_item',_remove_item);
		_formData.append('_wpnonce',_wpnonce);

		/**
		 * Send ajax
		 */
		$.ajax({
			'url': tm_ajax_commerce.ajaxurl,
			'type': 'POST',
			'dataType': 'json',
			'processData': false, // important
			'contentType': false, // important
			'cache': false,
			'data': _formData
		})
		.done(function( response ) {
			if(response.message) {
				var _cart_data = response.message;
				var $_tm_commerce_ajax_cart = $('.tm-commerce-ajax-cart');
				// update the cart info
				if(typeof _cart_data.cart_contents_count != 'undefined') $_tm_commerce_ajax_cart.find('.cart-indication .badge').text(_cart_data.cart_contents_count);
				if(typeof _cart_data.cart_overview_html != 'undefined') $_tm_commerce_ajax_cart.find('.cart-overview').html(_cart_data.cart_overview_html);
			} else {
				console.log('Error in data sent from the server.');
			}
		})
		.fail(function( response ) {
			console.log('There was an error in handling your request. Please try again later.');
		})
		.always(function( response ) {
		});
	}


	 /**
	  * Parses notices sent from woocommerce and display in the screen
	  */
	 function _showNoticesFromArray(boxMode,noticesArray) {
		if($('#tm-commerce-notices').length == 0) {
			$('<div id="tm-commerce-notices">').insertBefore('div.product_meta');
		}
		var $_targetMessageElement = $('#tm-commerce-notices');
		for(var _key in noticesArray){
			$_targetMessageElement.append('<div class="box '+boxMode+'">'+noticesArray[_key].replace(/<(a[^>]*?)>(.*?)<\/a>/ig, "")+'</div>');
		}
	};
});