<?php
/**
 * @link              https://thememountain.com
 * @package           tm-commerce
 *
 * Version:           1.1.7
 * @wordpress-plugin
 * Plugin Name:       ThemeMountain Commerce Plugin
 * Plugin URI:        https://thememountain.com
 * Description:       This is a support plugin for ThemeMountain WordPress theme products.
 * Author:            ThemeMountain
 * Author URI:        https://thememountain.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       thememountain-commerce
 * Domain Path:       /languages
 */

namespace ThemeMountain {
	// If this file is called directly, abort.
	if ( ! defined( 'WPINC' ) ) {
		die;
	}

	/** Activation hook  to check up plugin compatibility */
	register_activation_hook(__FILE__, function () {
		/** get plugin data */
		$_plugin_data = get_plugin_data(__FILE__, false, false);
		$_plugin_version = $_plugin_data['Version'];
		/* Create transient data */
		if (
			method_exists('ThemeMountain\TM_ThemeMountain', 'get_required_tmcommerce_version') === true &&
			version_compare($_plugin_version,TM_ThemeMountain::get_required_tmcommerce_version(), '>=') === false
		) :
			set_transient('tm-admin-notice-tmcommerce-cannot-be-activated', true, 5);
		elseif (thememountain_is_compatible_woocommerce_version_active() === FALSE) :
			set_transient('tm-admin-notice-tmcommerce-requires-woocommerce', true, 5);
		endif;
	}, 9999);

	add_action('admin_notices', function () {
		/* Check transient, if available display notice */
		if (get_transient('tm-admin-notice-tmcommerce-cannot-be-activated')) {
			?>
				<div class="error">
					<p><strong><?php echo esc_html__('ThemeMountain OneClick Plugin could not be activated.', 'thememountain-tmcommerce'); ?></strong> <?php echo esc_html__('Please make sure that you have installed the lastest ThemeMountain OneClick Plugin and ThemeMountain theme.', 'thememountain-tmcommerce'); ?></p>
				</div>
			<?php
			thememountain_cancel_tmcommerce_plugin_activation();
		} else if (get_transient('tm-admin-notice-tmcommerce-requires-woocommerce')) {
			?>
				<div class="error">
					<p><strong><?php echo esc_html__('ThemeMountain OneClick Plugin could not be activated.', 'thememountain-tmcommerce'); ?></strong> <?php echo esc_html__('Please make sure that you have installed the lastest WooCommerce Plugin.', 'thememountain-tmcommerce'); ?></p>
				</div>
			<?php
			thememountain_cancel_tmcommerce_plugin_activation();
		}
	});

	function thememountain_is_compatible_woocommerce_version_active ($version = '3.3.0') {
		if ( class_exists( 'WooCommerce' ) ) {
			global $woocommerce;
			if ( version_compare( $woocommerce->version, $version, ">=" ) ) {
				return true;
			}
		}
		return false;
	}

	function thememountain_cancel_tmcommerce_plugin_activation(){
		/** deactivate this plugin  */
		deactivate_plugins(__FILE__);
		/** Making sure that Plugin Activated message will not be shown */
		if (isset($_GET['activate'])) {
			unset($_GET['activate']);
		}
	}

	/**
	 * Making sure that the php version is 5.6 or later.
	 */
	if (version_compare(phpversion(), '5.6', '>')) {
		/* other variables */
		$_local_plugin_dir = plugin_dir_path( __FILE__ );
		$_local_plugin_dir_uri = plugins_url('', __FILE__ );

		/**
		 * TM_Ajax_Commerce for Cart Nav Menu
		 */
		require_once $_local_plugin_dir . 'class/TM_Ajax_Commerce.php';
		new TM_Ajax_Commerce(
			array (
				'local_plugin_dir' => $_local_plugin_dir,
				'local_plugin_dir_uri' => $_local_plugin_dir_uri,
			)
		);

		/**
		 * Admin
		 */
		require_once $_local_plugin_dir . 'class/TM_Commerce.php';
		new TM_Commerce(
			array (
				'local_plugin_dir' => $_local_plugin_dir,
				'local_plugin_dir_uri' => $_local_plugin_dir_uri,
			)
		);

		/**
		 * Cart Nav Menu
		 */
		require_once $_local_plugin_dir . 'class/TM_CartNavMenu.php';
		new TM_CartNavMenu(
			array (
				'local_plugin_dir' => $_local_plugin_dir,
				'local_plugin_dir_uri' => $_local_plugin_dir_uri,
			)
		);

		unset($_local_plugin_dir, $_local_plugin_dir_uri);
	}
}