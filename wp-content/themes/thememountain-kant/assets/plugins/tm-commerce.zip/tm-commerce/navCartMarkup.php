<ul>
	<li>
		<a href="#" class="contains-sub-menu cart">Cart <span class="cart-indication"><span class="badge">3</span></span></a>
		<ul class="sub-menu custom-content cart-overview">
			<li class="cart-item">
				<a href="single-product.html" class="product-thumbnail">
					<img src="images/shop/cart/cart-thumb-small.jpg" alt="" />
				</a>
				<div class="product-details">
					<a href="single-product.html" class="product-title">
						Cotton Jump Suit
					</a>
					<span class="product-quantity">2 x</span>
					<span class="product-price"><span class="currency">$</span>15.00</span>
					<a href="#" class="product-remove icon-cancel"></a>
				</div>
			</li>
			<li class="cart-item">
				<a href="single-product.html" class="product-thumbnail">
					<img src="images/shop/cart/cart-thumb-small-2.jpg" alt="" />
				</a>
				<div class="product-details">
					<a href="single-product.html" class="product-title">
						Crew Neck U.S Sweater
					</a>
					<span class="product-quantity">2 x</span>
					<span class="product-price"><span class="currency">$</span>45.00</span>
					<a href="#" class="product-remove icon-cancel"></a>
				</div>
			</li>
			<li class="cart-item">
				<a href="single-product.html" class="product-thumbnail">
					<img src="images/shop/cart/cart-thumb-small-3.jpg" alt="" />
				</a>
				<div class="product-details">
					<a href="single-product.html" class="product-title">
						Cross Summer Top
					</a>
					<span class="product-quantity">2 x</span>
					<span class="product-price"><span class="currency">$</span>17.00</span>
					<a href="#" class="product-remove icon-cancel"></a>
				</div>
			</li>
			<li class="cart-subtotal">
				Sub Total
				<span class="amount"><span class="currency">$</span>77.00</span>
			</li>
			<li class="cart-actions">
				<a href="cart.html" class="view-cart">View Cart</a>
				<a href="checkout.html" class="checkout"><span class="icon-check"></span> Checkout</a>
			</li>
		</ul>
	</li>
</ul>