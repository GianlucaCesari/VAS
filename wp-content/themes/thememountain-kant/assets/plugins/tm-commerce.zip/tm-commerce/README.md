# tm-commerce
Wordpress plugin to add e-commerce (woocommerce) feature to any ThemeMountain Wordpress Themes

## 1.1.7 (June 2018)
- Added proper error handlings to prevent 500 errors.
- Fixed: adding a single item in product page was broken.

## 1.1.6 (14 MAY 2018)
- Support for offcanvas / overlay cart added.

## 1.1.5 (25 APR 2018)
- Maitainances

## 1.1.4 (25 APR 2018)
- Fixed: Variable of Product is not added to the cart.

## 1.1.3 (9 APR 2018)
- Fixed: Error caused if the plugin is used without tm-plugin enabled.

## 1.1.2 (28 Feb 2018)
- Fixed: Variations are ignored when adding an item with variation with the ajax cart.

## 1.1.1 (10 Feb 2018)
- Add data-group attribute to woo commerce individual product page thumbnails #21
