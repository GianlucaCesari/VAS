<?php
/**
 * tm_button shortcode
 */

/**
 * Include the parent
 */
include('tm_aux_button.php');
