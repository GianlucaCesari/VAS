<?php
/**
 * tm_icon shortcode
 */

/**
 * Include the parent
 */
include('tm_aux_icon.php');
